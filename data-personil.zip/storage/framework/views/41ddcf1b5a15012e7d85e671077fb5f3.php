
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Kelola Akun/</span> <?php echo e($user->name); ?></h4>

        <!-- Basic Layout -->
        <div class="row">

            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Kelola Akun</h5>
                    <div class="d-flex">
                        <form action="<?php echo e(route('admin.kelola.delete.akun', $user->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-danger d-grid justify-content-center me-2">Hapus Akun</button>
                        </form>
                        <a href="<?php echo e(route('admin.kelola.akun.semua')); ?>" class="btn btn-md btn-outline-dark">Kembali</a>
                    </div>
                </div>
                <hr class="my-0" />
                <div class="card-body">
                    <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1" class="form-label">Nama</label>
                        <input class="form-control" type="text" id="exampleFormControlReadOnlyInput1"
                            value="<?php echo e($user->name); ?>" readonly />
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1" class="form-label">NRP/NIP</label>
                        <input class="form-control" type="text" id="exampleFormControlReadOnlyInput1"
                            value="<?php echo e($user->nrp_nip); ?>" readonly />
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1" class="form-label">Jabatan</label>
                        <input class="form-control" type="text" id="exampleFormControlReadOnlyInput1"
                            value="<?php echo e($user->jabatan); ?>" readonly />
                    </div>
                    <form id="formAuthentication" class="mb-3" action="<?php echo e(route('admin.kelola.update.akun', $user->id)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="mb-3">
                            <label for="email" class="form-label">
                                <div class="d-flex">
                                    <span class="me-2">Email</span>
                                    <p class="badge rounded-pill bg-secondary">*Email Lama : <?php echo e($user->email); ?></p>
                                </div>
                            </label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                                name="email" placeholder="Silahkan masukkan alamat email anda"
                                value="<?php echo e(old('email')); ?>" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button class="btn btn-dark justify-content-center">Update Akun</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\data-personil\resources\views/admin/edit_akun.blade.php ENDPATH**/ ?>