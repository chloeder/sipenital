
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Satuan Kerja/</span>Semua Bagian/Satker</h4>
    <div class="card mb-4">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0">Daftar Satuan Kerja</h5>

        </div>

        <hr class="my-0" />
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-striped table-hover py-3" id="myTable">
                    <thead>
                        <tr class="table-secondary">
                            <th>No</th>
                            <th>Nama</th>
                            <th>Pangkat</th>
                            <th>TMT Pangkat</th>
                            <th>TMT Berkala</th>
                            <th>NRP/NIP</th>
                            <th>Satuan Kerja</th>
                            <th>Jabatan</th>
                            <th>TMT Jabatan</th>
                            <th>Status Marital</th>
                            <th>Nama Isteri/Suami</th>
                            <th>Agama</th>
                            <th>Tanggal Lahir</th>
                            <th>Alamat</th>
                            <th>No HP</th>
                            <th>Fasilitas Kesehatan</th>
                            <th>No BPJS</th>
                            <th>NIK</th>
                            <th>Kasus</th>
                            <th>Keterangan</th>
                            <th>Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $personil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(
                                $p->nama == null ||
                                    $p->pangkat == null ||
                                    $p->tmt_pangkat == null ||
                                    $p->tmt_berkala == null ||
                                    $p->nrp_nip == null ||
                                    $p->satker->nama_satker == null ||
                                    $p->jabatan == null ||
                                    $p->tmt_jabatan == null ||
                                    $p->status_marital == null ||
                                    $p->nama_pasangan == null ||
                                    $p->agama == null ||
                                    $p->tanggal_lahir == null ||
                                    $p->alamat == null ||
                                    $p->no_hp == null ||
                                    $p->fasilitas_kesehatan == null ||
                                    $p->no_bpjs == null ||
                                    $p->nik == null ||
                                    $p->kasus == null ||
                                    $p->keterangan == null): ?>
                                <tr class="table-danger">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <?php if($p->nama == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nama); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->pangkat == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->pangkat); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tmt_pangkat == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tmt_pangkat); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tmt_berkala == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tmt_berkala); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->nrp_nip == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nrp_nip); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->satker->nama_satker == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->satker->nama_satker); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->jabatan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->jabatan); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tmt_jabatan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tmt_jabatan); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->status_marital == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->status_marital); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->nama_isteri_suami == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nama_isteri_suami); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->agama == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->agama); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tanggal_lahir == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tanggal_lahir); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->alamat == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->alamat); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->no_hp == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->no_hp); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->fasilitas_kesehatan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->fasilitas_kesehatan); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->no_bpjs == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->no_bpjs); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->nik == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nik); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->kasus == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->kasus); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->keterangan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->keterangan); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.personil.detail', $p->id)); ?>">
                                                    Lihat Detail</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <?php if($p->nama == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nama); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->pangkat == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->pangkat); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tmt_pangkat == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tmt_pangkat); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tmt_berkala == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tmt_berkala); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->nrp_nip == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nrp_nip); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->satker->nama_satker == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->satker->nama_satker); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->jabatan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->jabatan); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tmt_jabatan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tmt_jabatan); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->status_marital == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->status_marital); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->nama_isteri_suami == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nama_isteri_suami); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->agama == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->agama); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->tanggal_lahir == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->tanggal_lahir); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->alamat == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->alamat); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->no_hp == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->no_hp); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->fasilitas_kesehatan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->fasilitas_kesehatan); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->no_bpjs == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->no_bpjs); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->nik == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->nik); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->kasus == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->kasus); ?></td>
                                    <?php endif; ?>
                                    <?php if($p->keterangan == null): ?>
                                        <td class="fst-italic fw-light">Kosong</td>
                                    <?php else: ?>
                                        <td><?php echo e($p->keterangan); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.personil.detail', $p->id)); ?>">
                                                    Lihat Detail</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <?php $__env->startPush('js'); ?>
        <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

        <script>
            $(document).ready(function() {
                $('#myTable').DataTable();
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\data-personil\resources\views/admin/lengkap.blade.php ENDPATH**/ ?>