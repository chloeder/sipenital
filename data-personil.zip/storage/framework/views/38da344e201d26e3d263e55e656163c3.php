
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-sm-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-center justify-content-between">
                        <div>
                            <span class="fw-semibold d-block mb-1">Total Personil</span>
                            <p class="card-title mb-2"><?php echo e($current_personil); ?> dari <?php echo e($count_personil); ?> Personil</p>
                        </div>
                        <?php if($percentage_personil == 100): ?>
                            <div>
                                <h5 class="fw-bold text-success">
                                    <i class="bx bx-up-arrow-alt"></i><?php echo e($percentage_personil); ?>%
                                </h5>
                            </div>
                        <?php elseif($percentage_personil >= 50): ?>
                            <div>
                                <h5 class="fw-bold text-warning">
                                    <i class="bx bx-minus"></i><?php echo e($percentage_personil); ?>%
                                </h5>
                            </div>
                        <?php else: ?>
                            <div>
                                <h5 class="fw-bold text-danger">
                                    <i class="bx bx-down-arrow-alt"></i><?php echo e($percentage_personil); ?>%
                                </h5>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-sm-12 col-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-center justify-content-between">
                        <div>
                            <span class="fw-semibold d-block mb-1">Jabatan Terisi</span>
                            <p class="card-title mb-2"><?php echo e($current_personil); ?> dari <?php echo e($count_personil); ?> Jabatan</p>
                        </div>
                        <?php if($percentage_personil == 100): ?>
                            <div>
                                <h5 class="fw-bold text-success">
                                    <i class="bx bx-up-arrow-alt"></i><?php echo e($percentage_personil); ?>%
                                </h5>
                            </div>
                        <?php elseif($percentage_personil >= 50): ?>
                            <div>
                                <h5 class="fw-bold text-warning">
                                    <i class="bx bx-minus"></i><?php echo e($percentage_personil); ?>%
                                </h5>
                            </div>
                        <?php else: ?>
                            <div>
                                <h5 class="fw-bold text-danger">
                                    <i class="bx bx-down-arrow-alt"></i><?php echo e($percentage_personil); ?>%
                                </h5>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                </div>
            </div>
        </div>

    </div>
    <div class="card mb-4">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0"><?php echo e($satker->nama_satker); ?></h5>
            <div>
                <button type="button" class="btn btn-md btn-outline-success" data-bs-toggle="modal"
                    data-bs-target="#backDropModal">Import Excel
                </button>
                <a href="<?php echo e(route('admin.satker')); ?>" class="btn btn-md btn-outline-dark">Kembali</a>
            </div>
        </div>
        <hr class="my-0" />
        <div class="card-body">

            

            <div class="table-responsive text-nowrap">
                <table class="table table-hover my-3" id="myTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Jabatan</th>
                            <th>Nama Personil</th>
                            <th>Pangkat</th>
                            <th>NRP/NIP</th>
                            <th>Aksi</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $personil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->nama == null): ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($p->jabatan); ?></td>
                                    <td class="fst-italic fw-bold">
                                        <span class="badge rounded-pill bg-label-danger">Kosong</span>
                                    </td>
                                    <td class="fst-italic fw-bold">
                                        <span class="badge rounded-pill bg-label-danger">Kosong</span>
                                    </td>
                                    <td class="fst-italic fw-bold">
                                        <span class="badge rounded-pill bg-label-danger">Kosong</span>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.personil.detail', $p->id)); ?>">
                                                    Lihat Detail</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($p->jabatan); ?></td>
                                    <td><?php echo e($p->nama); ?></td>
                                    <td><?php echo e($p->pangkat); ?></td>
                                    <td><?php echo e($p->nrp_nip); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.personil.detail', $p->id)); ?>">
                                                    Edit Personil</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal -->

    <div class="modal fade" id="backDropModal" data-bs-backdrop="static" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" action="<?php echo e(route('admin.personil.import')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="backDropModalTitle">Import File Excel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <hr>
                <div class="modal-body">
                    <div class="input-group">

                        <input type="file" class="form-control" name="file" id="inputGroupFile01" />
                        <label class="input-group-text" for="inputGroupFile02">Upload</label>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-success">Import</button>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

        <script>
            $(document).ready(function() {
                $('#myTable').DataTable();
            });
        </script>
    <?php $__env->stopPush(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\data-personil\resources\views/admin/struktur.blade.php ENDPATH**/ ?>