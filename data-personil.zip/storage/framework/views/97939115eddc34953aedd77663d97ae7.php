
<?php $__env->startSection('content'); ?>
    <div class="card">
        <h5 class="card-header">Daftar Personil</h5>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Satuan Kerja</th>
                            <th>Tanggal Lahir</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Angular Project</strong>
                            </td>
                            <td>
                                <a href="<?php echo e(route('dashboard.petugas')); ?>" target="_blank" style="text-decoration: black">
                                    <span>Bagian Operasional</span>
                                </a>
                            </td>
                            <td>
                                <span>25 Maret 2000</span>
                            </td>
                            <td><span
                                    class="badge
                                        bg-label-primary me-1">Active</span>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="bx bx-dots-vertical-rounded"></i>
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void(0);"><i
                                                class="bx bx-edit-alt me-1"></i> Edit</a>
                                        <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i>
                                            Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Angular Project</strong>
                            </td>
                            <td>
                                <a href="<?php echo e(route('dashboard.petugas')); ?>" target="_blank" style="text-decoration: black">
                                    <span>Bagian Operasional</span>
                                </a>
                            </td>
                            <td>
                                <span>25 Maret 2000</span>
                            </td>
                            <td><span
                                    class="badge
                                        bg-label-primary me-1">Active</span>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="bx bx-dots-vertical-rounded"></i>
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void(0);"><i
                                                class="bx bx-edit-alt me-1"></i> Edit</a>
                                        <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i>
                                            Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Angular Project</strong>
                            </td>
                            <td>
                                <a href="<?php echo e(route('dashboard.petugas')); ?>" target="_blank" style="text-decoration: black">
                                    <span>Bagian Operasional</span>
                                </a>
                            </td>
                            <td>
                                <span>25 Maret 2000</span>
                            </td>
                            <td><span
                                    class="badge
                                        bg-label-primary me-1">Active</span>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="bx bx-dots-vertical-rounded"></i>
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="javascript:void(0);"><i
                                                class="bx bx-edit-alt me-1"></i> Edit</a>
                                        <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i>
                                            Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\data-personil\resources\views/petugas/personil.blade.php ENDPATH**/ ?>