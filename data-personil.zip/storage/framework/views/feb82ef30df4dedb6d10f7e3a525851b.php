
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 ">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Detail Personil/</span><?php echo e($personil->nama); ?></h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <div class="card mb-4">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">Detail Personil</h5>
                    <a href="<?php echo e(route('admin.personil')); ?>" class="btn btn-md btn-outline-dark">Kembali</a>
                </div>
                <hr class="my-0" />
                <div class="card-body">
                    <form action="<?php echo e(route('admin.personil.update', $personil->id)); ?>" id="formAccountSettings"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-name">Nama </label>
                                <?php if($personil->nama == null): ?>
                                    <input type="text" name="nama" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="nama" class="form-control" id="basic-default-name"
                                        value="<?php echo e($personil->nama); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Pangkat</label>
                                <?php if($personil->pangkat == null): ?>
                                    <input type="text" name="pangkat" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="pangkat" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->pangkat); ?>" />
                                <?php endif; ?>

                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">TMT Pangkat</label>
                                <?php if($personil->tmt_pangkat == null): ?>
                                    <input type="date" name="tmt_pangkat" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="date" name="tmt_pangkat" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->tmt_pangkat); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">TMT Berkala</label>
                                <?php if($personil->tmt_berkala == null): ?>
                                    <input type="date" name="tmt_berkala" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="date" name="tmt_berkala" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->tmt_berkala); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">NRP/NIP</label>
                                <?php if($personil->nrp_nip == null): ?>
                                    <input type="text" name="nrp_nip" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="nrp_nip" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->nrp_nip); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Satuan
                                    Kerja</label>
                                <select id="defaultSelect" class="form-select" name="satker_id">
                                    <option>Pilih Satuan Kerja</option>
                                    <?php $__currentLoopData = $satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($s->id); ?>"
                                            <?php echo e($personil->satker_id == $s->id ? 'selected' : ''); ?>>
                                            <?php echo e($s->nama_satker); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Jabatan</label>
                                <?php if($personil->jabatan == null): ?>
                                    <input type="text" name="jabatan" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="jabatan" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->jabatan); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">TMT -
                                    Jabatan</label>
                                <?php if($personil->tmt_jabatan == null): ?>
                                    <input type="date" name="tmt_jabatan" class="form-control"
                                        id="basic-default-name" value="" />
                                <?php else: ?>
                                    <input type="date" name="tmt_jabatan" class="form-control"
                                        id="basic-default-company" value="<?php echo e($personil->tmt_jabatan); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Status
                                    Marital</label>
                                <select id="defaultSelect" class="form-select" name="status_marital">
                                    <option>Status Marital</option>
                                    <option value="KAWIN" <?php echo e($personil->status_marital == 'KAWIN' ? 'selected' : ''); ?>>
                                        KAWIN</option>
                                    <option value="BLM KAWIN"
                                        <?php echo e($personil->status_marital == 'BLM KAWIN' ? 'selected' : ''); ?>>
                                        BLM
                                        KAWIN</option>
                                </select>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Nama
                                    Isteri/Suami</label>
                                <?php if($personil->nama_isteri_suami == null): ?>
                                    <input type="text" name="nama_isteri_suami" class="form-control"
                                        id="basic-default-name" value="" />
                                <?php else: ?>
                                    <input type="text" name="nama_isteri_suami" class="form-control"
                                        id="basic-default-company" value="<?php echo e($personil->nama_isteri_suami); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Agama</label>
                                <select id="defaultSelect" class="form-select" name="agama">
                                    <option>Agama</option>
                                    <option value="ISLAM" <?php echo e($personil->agama == 'ISLAM' ? 'selected' : ''); ?>>
                                        ISLAM
                                    </option>
                                    <option value="PROTESTAN" <?php echo e($personil->agama == 'PROTESTAN' ? 'selected' : ''); ?>>
                                        PROTESTAN
                                    </option>
                                    <option value="KATOLIK" <?php echo e($personil->agama == 'KATOLIK' ? 'selected' : ''); ?>>
                                        KATOLIK
                                    </option>
                                    <option value="HINDU" <?php echo e($personil->agama == 'HINDU' ? 'selected' : ''); ?>>
                                        HINDU
                                    </option>
                                    <option value="BUDDHA" <?php echo e($personil->agama == 'BUDDHA' ? 'selected' : ''); ?>>
                                        BUDDHA
                                    </option>
                                    <option value="KHONGHUCU" <?php echo e($personil->agama == 'KHONGHUCU' ? 'selected' : ''); ?>>
                                        KHONGHUCU
                                    </option>
                                </select>

                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Tangga Lahir</label>
                                <?php if($personil->tanggal_lahir == null): ?>
                                    <input type="date" name="tanggal_lahir" class="form-control"
                                        id="basic-default-name" value="" />
                                <?php else: ?>
                                    <input type="date" name="tanggal_lahir" class="form-control"
                                        id="basic-default-company" value="<?php echo e($personil->tanggal_lahir); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Alamat</label>
                                <?php if($personil->alamat == null): ?>
                                    <input type="text" name="alamat" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="alamat" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->alamat); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">No
                                    Telepon</label>
                                <?php if($personil->no_hp == null): ?>
                                    <input type="text" name="no_hp" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="no_hp" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->no_hp); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Fasilitas
                                    Kesehatan</label>
                                <?php if($personil->fasilitas_kesehatan == null): ?>
                                    <input type="text" name="fasilitas_kesehatan" class="form-control"
                                        id="basic-default-name" value="" />
                                <?php else: ?>
                                    <input type="text" name="fasilitas_kesehatan" class="form-control"
                                        id="basic-default-company" value="<?php echo e($personil->fasilitas_kesehatan); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">No BPJS</label>
                                <?php if($personil->no_bpjs == null): ?>
                                    <input type="text" name="no_bpjs" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="no_bpjs" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->no_bpjs); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">NIK</label>
                                <?php if($personil->nik == null): ?>
                                    <input type="text" name="nik" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="nik" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->nik); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col-md-6">
                                <label class="form-label fw-bolder" for="basic-default-company">Kasus</label>
                                <?php if($personil->kasus == null): ?>
                                    <input type="text" name="kasus" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="kasus" class="form-control" id="basic-default-company"
                                        value="<?php echo e($personil->kasus); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="mb-4 col">
                                <label class="form-label fw-bolder" for="basic-default-company">Keterangan</label>
                                <?php if($personil->keterangan == null): ?>
                                    <input type="text" name="keterangan" class="form-control" id="basic-default-name"
                                        value="" />
                                <?php else: ?>
                                    <input type="text" name="keterangan" class="form-control"
                                        id="basic-default-company" value="<?php echo e($personil->keterangan); ?>" />
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="mt-2">
                            <button type="submit" class="btn btn-primary me-2">Simpan</button>

                        </div>
                    </form>
                </div>
                <!-- /Account -->
            </div>
            <!-- Basic with Icons -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\data-personil\resources\views/admin/detail_personil.blade.php ENDPATH**/ ?>