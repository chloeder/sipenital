WELCOME

<a href="<?php echo e(route('login')); ?>">LOGIN</a>
<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
    <i class="bx bx-power-off me-2"></i>
    <span class="align-middle">Log Out</span>
</a>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
</form>
<?php /**PATH C:\Users\asus\Desktop\data-personil\resources\views/welcome.blade.php ENDPATH**/ ?>